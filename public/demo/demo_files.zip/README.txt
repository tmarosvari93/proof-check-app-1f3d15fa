Fictional demo files for Proof Check. Product: Mezolak Mangos instant zabkasa (fictional).
1. Create a request with spec_SP-2026-0417_v3.xlsx
2. Upload proof_v1.pdf, then proof_v2.pdf, then proof_v3.pdf (round 1, 2, 3)
3. The *_flat.pdf files are the same proofs as images (no text layer).
